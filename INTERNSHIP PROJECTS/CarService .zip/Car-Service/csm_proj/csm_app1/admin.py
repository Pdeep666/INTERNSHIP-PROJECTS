from django.contrib import admin
from csm_app1.models import Registration
# Register your models here.
admin.site.register(Registration)